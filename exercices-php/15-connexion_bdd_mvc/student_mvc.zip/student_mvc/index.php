<?php
// Contrôleur principal

require_once('vue/head.php');
require_once('modele/connect_bdd.php');


//resetDb();


$table = $_GET['table'] ?? '';
$id = intval($_GET['id'] ?? -1);
$op = $_GET['op'] ?? '';

if ($table === 'tag' || $table === '') {
  require('modele/Tag.php');

  /*
  $tag = Tag::select(1);
  $tag->name = 'testInsert';
  $tag->description = 'testInsert';
  $tag->insert();
  */
  /*
  $tag->name = 'testInsert';
  $tag->description = 'testInsert';
  $tag->insert();
  $tag->name = 'testUpdate';
  $tag->description = 'testUpdate';
  $tag->update();
*/

  if ($op === 'delete') {
    if ($id > 0) {
      $tag = Tag::select($id);
      try {
        $tag->deleteCurrent();
      } catch (PDOException $deletePdoException) {
      }
      $tags = Tag::all();
      require_once('vue/tag_supprime.php');
      require_once('vue/tag_liste.php');
    }
  } else {
    $tags = Tag::all();
    require_once('vue/tag_liste.php');
  }
}



require_once('vue/foot.php');
