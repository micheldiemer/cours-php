<?php

// Paramètre de connexion confidentiels
include_once('env.php');

// Paramètres de connexion par défaut
$bdd_username = $bdd_username ?? 'student';
$bdd_password = $bdd_password ?? 'student';
$bdd_host = $bdd_host ?? 'localhost';
$bdd_port = $bdd_port ?? 3306;
$bdd_dbname = $bdd_dbname ?? 'src_mariadb';
$dsn = "mysql:host=$bdd_host;port=$bdd_port;dbname=$bdd_dbname; charset=UTF8";
$options =
  [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

    PDO::ATTR_DEFAULT_FETCH_MODE =>
    PDO::FETCH_ASSOC
  ];

try {
  // Connexion à la base de donnée
  $pdo = new PDO($dsn, $bdd_username, $bdd_password, $options);
} catch (PDOException $e) {
  // en cas d'erreur
  echo "Erreur connexion à la base de données<br>";
  echo $e->getCode() . ' ' . $e->getMessage() . '<br>';
  http_response_code(500);
  $pdo = null;
}

function getPdo()
{
  global $pdo;
  return $pdo;
}


function resetDb()
{
  global $pdo;
  $sql = file_get_contents('modele/student.sql');
  $pdo->exec($sql);
}
