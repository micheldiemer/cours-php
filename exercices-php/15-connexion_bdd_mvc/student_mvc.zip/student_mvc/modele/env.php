<?php
// Paramètres de connexion confidentiels
$bdd_username = 'src_mariadb';
$bdd_password = '8Sd9BDHgQBh(O_Yc';
$bdd_dbname = 'src_mariadb';
