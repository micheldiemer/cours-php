<table>

  <tr>
    <th>Nom</th>
    <th>Description</th>
  </tr>

  <?php
  foreach ($tags as $tag) { ?>
    <tr>
      <td><?= $tag['name'] ?></td>
      <td><?= $tag['description'] ?></td>
      <td>🖊️</td>
      <td><a href="index.php?table=tag&id=<?= $tag['id'] ?>&op=delete">❌</a></td>
    </tr>
  <?php } ?>
</table>