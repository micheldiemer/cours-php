<?php

require('head.php');
?>
<h1>Page User</h1>

Bienvenue <?= $pseudo ?><br>
<a href='deconnexion.php'>Se déconnecter</a>
<?php
require('foot.php');
?>