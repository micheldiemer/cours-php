﻿<?php
$title = 'Article';
require('head.php');
?>

Ceci est un article très intéressant
<?php
require('foot.php');
