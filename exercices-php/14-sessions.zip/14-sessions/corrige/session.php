<?php
/*
  - Vérifie si l'utilisateur est connecté ou non
  - Gestion des permissions/droits d'accès aux pages et aux scripts php
  - Effectue les redirections nécessaires
  - Gestion des routes rudimentaires
*/
const ROLE_USER = 'User';
const ROLE_ADMIN = 'Admin';
session_start();


$pseudo = '';
$role = '';
if (isset($_SESSION['connecte']) && isset($_SESSION['pseudo']) && isset($_SESSION['role'])) {
  // La session existe, l'utilistateur est connecté, les informations sont correctes

  // Vérification du script php auquel l'utilisateur veut accéder
  $pseudo = $_SESSION['pseudo'];
  $role = $_SESSION['role'];
  if (str_ends_with($_SERVER['SCRIPT_NAME'], 'secrete_1.php')) {
    // Tentative d'accès à la page secrète 1
    if ($role != ROLE_USER && $role != ROLE_ADMIN) {
      header('Location: login.php');
      exit();
    }
  } else if (str_ends_with($_SERVER['SCRIPT_NAME'], 'secrete_2.php')) {
    // Tentative d'accès à la page secrète 2
    if ($role != ROLE_ADMIN) {
      header('Location: login.php');
      exit();
    }
  } else if (str_ends_with($_SERVER['SCRIPT_NAME'], 'login.php')) {
    // Tentative d'accès à la page secrète d'authentification
    // alors qu'on est déjà connecté
    switch ($role) {
      case ROLE_USER:
        header('Location: secrete_1.php');
        exit();
      case ROLE_ADMIN:
        header('Location: secrete_2.php');
        exit();
      default:
        session_destroy();
        session_start();
    }
  } else if (str_ends_with($_SERVER['SCRIPT_NAME'], 'deconnexion.php')) {
  } else if (str_ends_with($_SERVER['SCRIPT_NAME'], 'article.php')) {
  } else if (str_ends_with($_SERVER['SCRIPT_NAME'], 'profil.php')) {
  } else {
    // l'utilisateur connecté essaye d'accéder à une page/un script
    // auquel il ne devrait pas => redirection vers profil.php
    header('Location: profil.php');
    exit();
  }
} else {
  // Soit la session n'existe pas soit ses données sont corrompues
  session_destroy();
  session_start();
  // Page profil : l'utilisateur tente de se connecter ; c'est ok
  if (str_ends_with($_SERVER['SCRIPT_NAME'], 'profil.php')) {
  }
  // Retour obligatoire à la page de login
  else if (!str_ends_with($_SERVER['SCRIPT_NAME'], 'login.php')) {
    header('Location: login.php');
    exit();
  }
}
