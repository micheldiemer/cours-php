<?php

$bdd_username = 'utilisateurPhp';
$bdd_password = 'QkyMNSyNYtr1z]63';
$bdd_name = 'utilisateur';
$bdd_host = 'localhost';

try {
  $dsn = "mysql:host=$bdd_host;dbname=$bdd_name";
  $pdo = new PDO($dsn, $bdd_username, $bdd_password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE,   PDO::ERRMODE_EXCEPTION);
  $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  echo 'Erreur connexion base de données<br>';
  echo 'Code : ' . $e->getCode() . ' Message : ' . $e->getMessage() . '<br>';
  echo 'DSN=' . $dsn . '<br>';
  echo 'username=' . $bdd_username . '<br>';
  echo 'longueur du mot de passe : ' . mb_strlen($bdd_password) . '<br>';
  http_response_code(500);
  die();
}



function getAllUsers()
{

  global $pdo;

  $sql = "select utilisateur.login as pseudo, utilisateur.`password`, role.nom as role from utilisateur join role on role.id = utilisateur.role_id";

  $stmt = $pdo->query($sql);
  $data = $stmt->fetchAll();
  /*echo '<pre>';
  var_dump($data);
  echo '</pre>';*/
  return $data;
}


//getAllUsers();
